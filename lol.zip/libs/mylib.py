def pls_import_me():
    print("You imported me <3")